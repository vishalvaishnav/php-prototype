<?php
require_once 'vendor/autoload.php';
 
use \Firebase\JWT\JWT;
use GuzzleHttp\Client;

define('ZOOM_API_KEY', 'Your Zoom Api Key'); // update must be required
define('ZOOM_SECRET_KEY', 'Your Zoom Api Secret'); // // update must be required
 
function getZoomAccessToken() {
    $key = ZOOM_SECRET_KEY;
    $payload = array(
        "iss" => ZOOM_API_KEY,
        'exp' => time() + 3600,
    );
    return JWT::encode($payload, $key);    
}

function createZoomMeeting() {
    $response_data = array();
    $client = new Client([
        // Base URI is used with relative requests
        'base_uri' => 'https://api.zoom.us',
    ]);
 
    $response = $client->request('POST', '/v2/users/me/meetings', [
        "headers" => [
            "Authorization" => "Bearer " . getZoomAccessToken()
        ],
        'json' => [
            "topic" => "Let's Learn",
            "type" => 2,
            "start_time" => "2021-01-30T20:30:00",
            "duration" => "30", // 30 mins
            "password" => "123456"
        ],
    ]);
 
    $zoom_response = json_decode($response->getBody());
    if(count(array($zoom_response)) > 0){
        $response_data['url'] = $zoom_response->join_url;
    }
    return $response_data;
}