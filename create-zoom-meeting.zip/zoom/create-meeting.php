<?php
require('zoom-lib.php');

$response = createZoomMeeting();
if(count($response) > 0){
    echo "Zoom Meeting Join Url ".$response['url'];
}
else{
    echo "Something went wrong !!!";
}